// Top-level: bypass DesignCanvas (it was hiding artboards behind a pan/zoom
// the user couldn't see). Stack the three directions vertically with simple
// labels — every direction is in the viewport on load.

function App() {
  const [focus, setFocus] = React.useState('a'); // null | 'a' | 'b' | 'c'

  const dirs = [
    { id: 'a', label: 'A · Subway map',     sub: 'Clean horizontal DAG. Decision diamond mid-flow. Parallel lane below the spine. Right-rail inspector.', Comp: window.DirASubway },
    { id: 'b', label: 'B · Track + Gantt',  sub: 'Topology strip up top. Gantt below with a NOW line and decision marker — best for time + parallelism.',  Comp: window.DirBGantt },
    { id: 'c', label: 'C · Compute graph',  sub: 'Dense metric-rich nodes on a dotted canvas. Branches labeled (llm / parallel / heuristic). Power-user.', Comp: window.DirCCompute },
  ];

  const visible = focus ? dirs.filter(d => d.id === focus) : dirs;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-page)', color: 'var(--fg-1)' }}>
      <div style={{ position: 'sticky', top: 0, zIndex: 10, padding: '14px 24px', background: 'rgba(13,17,23,.92)', backdropFilter: 'blur(8px)', borderBottom: '1px solid var(--border-1)', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div>
          <div style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600 }}>TestLookup · /agents redesign</div>
          <div style={{ fontSize: 17, color: 'var(--fg-1)', fontWeight: 600, marginTop: 2 }}>3 DAG directions for the workflows pane</div>
        </div>
        <span style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 4, padding: 3, background: 'var(--bg-2)', border: '1px solid var(--border-1)', borderRadius: 8 }}>
          <button onClick={() => setFocus(null)}
            style={{ padding: '6px 11px', fontSize: 12, borderRadius: 5, border: 0, cursor: 'pointer',
                     background: focus === null ? 'var(--bg-3)' : 'transparent',
                     color: focus === null ? 'var(--fg-1)' : 'var(--fg-3)' }}>All three</button>
          {dirs.map(d => (
            <button key={d.id} onClick={() => setFocus(d.id)}
              style={{ padding: '6px 11px', fontSize: 12, borderRadius: 5, border: 0, cursor: 'pointer',
                       background: focus === d.id ? 'var(--bg-3)' : 'transparent',
                       color: focus === d.id ? 'var(--fg-1)' : 'var(--fg-3)' }}>{d.label.split(' · ')[0]}</button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 28, padding: '24px 24px 60px' }}>
        {visible.map(d => (
          <section key={d.id}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginBottom: 10 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-4)', width: 28 }}>{d.id.toUpperCase()}</div>
              <div>
                <div style={{ fontSize: 16, color: 'var(--fg-1)', fontWeight: 600 }}>{d.label}</div>
                <div style={{ fontSize: 12, color: 'var(--fg-3)', marginTop: 2 }}>{d.sub}</div>
              </div>
            </div>
            <div style={{ height: 900, width: '100%', minWidth: 1280, border: '1px solid var(--border-1)', borderRadius: 12, overflow: 'hidden', background: 'var(--bg-page)' }}>
              <d.Comp />
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
