/* Synthetic data for an in-flight Deep Pipeline run.
   Hits every state we need to design for: done, running (with progress), skipped (off-branch),
   failed (with retry queued), pending, and a decision diamond.                                  */

const RUN = {
  id: '7f4e9c2a-b5d3-4d11-9e6c-1b2f8a3e5d27',
  shortId: '7f4e9c2a',
  branch: 'release/v4.21',
  triggeredBy: 'Auto · CI hook',
  startedAt: '2026-05-10T16:08:13Z',
  startedAtLabel: 'Today at 16:08:13',
  elapsed: '1m 22s',
  pipeline: 'deep',
  llmMode: true,
  totalTests: 1284,
  failedCount: 17,
};

/* Stages: keyed by id, ordered, with a column index used by both subway-map (A) and gantt (B). */
const STAGES = [
  { id: 'ingestion',  name: 'Ingestion',           desc: 'Load, validate, and enrich the run data',
    status: 'done', dur: '12s', startMs: 0,    endMs: 12,
    col: 0, row: 0, branch: 'main',
    metrics: { confidence: '—', evidence: 0, tokens: 0, cost: '$0.00' },
    glyph: 'database' },

  { id: 'anomaly',    name: 'Anomaly Detection',   desc: 'Compare against baselines, surface regressions',
    status: 'done', dur: '45s', startMs: 12, endMs: 57,
    col: 1, row: 0, branch: 'main',
    metrics: { confidence: '87%', evidence: 14, tokens: '12.4k', cost: '$0.08' },
    glyph: 'alert' },

  { id: 'rca',        name: 'Root Cause Analysis', desc: 'ReAct investigation across logs, traces, history',
    status: 'running', dur: '1m 22s', startMs: 60, endMs: 142, etaMs: 175,
    col: 3, row: 0, branch: 'llm',
    metrics: { confidence: '—', evidence: 9, tokens: '48.1k', cost: '$0.62' },
    glyph: 'bot' },

  { id: 'cluster',    name: 'Failure Clustering',  desc: 'Group related failures into defect-shaped clusters',
    status: 'done', dur: '3s', startMs: 60, endMs: 63,
    col: 3, row: 1, branch: 'parallel',
    metrics: { confidence: '94%', evidence: 4, tokens: 0, cost: '$0.00' },
    glyph: 'layers' },

  { id: 'triage',     name: 'Defect Triage',       desc: 'Prepare Jira-ready defects and owner guidance',
    status: 'skipped', dur: '—', skipReason: 'Not on the LLM analysis branch — heuristic-mode only.',
    col: 4, row: 1, branch: 'heuristic',
    metrics: {}, glyph: 'bug' },

  { id: 'flaky',      name: 'Flaky Sentinel',      desc: 'Detect recurring flaky or unstable tests',
    status: 'failed', dur: '8s · retry 1/3 queued', startMs: 63, endMs: 71,
    col: 4, row: 1, branch: 'parallel',
    metrics: { confidence: '—', evidence: 0, tokens: 0, cost: '$0.00' },
    error: 'ConnectionError: clickhouse://flaky-store timed out after 5s',
    glyph: 'warn' },

  { id: 'health',     name: 'Test Health',         desc: 'Inspect test-code anti-patterns and health risks',
    status: 'pending', dur: '—',
    col: 5, row: 1, branch: 'parallel',
    metrics: {}, glyph: 'stethoscope' },

  { id: 'summary',    name: 'Summary',             desc: 'Compose the executive and role-specific narrative',
    status: 'pending', dur: '—',
    col: 6, row: 0, branch: 'main',
    metrics: {}, glyph: 'file' },

  { id: 'release',    name: 'Release Risk',        desc: 'Turn the run into a go / conditional-go / no-go call',
    status: 'pending', dur: '—',
    col: 7, row: 0, branch: 'main',
    metrics: {}, glyph: 'shield' },
];

const DECISION = {
  id: 'route_analysis_mode',
  label: 'route_analysis_mode',
  chosen: 'llm',
  alternatives: ['heuristic', 'llm'],
  at: '16:08:13.59',
  rationale: '17 failures > heuristic threshold (5). Routing to LLM.',
  col: 2, row: 0,
};

/* Collapsed event feed — 1 row per stage event; decisions get their own row. */
const EVENTS = [
  { kind: 'started',   stage: 'ingestion',  at: '16:08:13', what: 'Ingestion started' },
  { kind: 'completed', stage: 'ingestion',  at: '16:08:13', what: 'Ingestion · 12s · 1284 tests loaded' },
  { kind: 'started',   stage: 'anomaly',    at: '16:08:13', what: 'Anomaly Detection started' },
  { kind: 'completed', stage: 'anomaly',    at: '16:08:58', what: 'Anomaly Detection · 45s · 17 regressions' },
  { kind: 'decision',  stage: 'route_analysis_mode', at: '16:08:58', what: '◇ route_analysis_mode → llm' },
  { kind: 'started',   stage: 'cluster',    at: '16:08:58', what: 'Failure Clustering started' },
  { kind: 'started',   stage: 'rca',        at: '16:08:58', what: 'Root Cause Analysis started' },
  { kind: 'completed', stage: 'cluster',    at: '16:09:01', what: 'Failure Clustering · 3s · 4 clusters' },
  { kind: 'started',   stage: 'flaky',      at: '16:09:01', what: 'Flaky Sentinel started' },
  { kind: 'failed',    stage: 'flaky',      at: '16:09:09', what: 'Flaky Sentinel failed · clickhouse timeout' },
  { kind: 'retry',     stage: 'flaky',      at: '16:09:09', what: 'Retry queued (attempt 1 of 3)' },
];

const RECENT_RUNS = [
  { id: '7f4e9c2a', label: 'release/v4.21',    when: 'Now',          status: 'running' },
  { id: '0a3b1c5e', label: 'release/v4.21',    when: '2 hr ago',     status: 'done'    },
  { id: '8c9d4f0a', label: 'main · #2812',     when: '4 hr ago',     status: 'done'    },
  { id: '5e2f7a31', label: 'fix/csv-import',   when: 'Yesterday',    status: 'failed'  },
  { id: 'a14d9e02', label: 'main · #2810',     when: 'Yesterday',    status: 'done'    },
];

/* Tiny inline SVGs we re-use. */
function Glyph({ name, className }) {
  const s = { width: 14, height: 14, fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (name) {
    case 'database':    return <svg {...s} className={className} viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v6c0 1.66 4.03 3 9 3s9-1.34 9-3V5"/><path d="M3 11v6c0 1.66 4.03 3 9 3s9-1.34 9-3v-6"/></svg>;
    case 'alert':       return <svg {...s} className={className} viewBox="0 0 24 24"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>;
    case 'bot':         return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>;
    case 'layers':      return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"/><path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"/><path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"/></svg>;
    case 'bug':         return <svg {...s} className={className} viewBox="0 0 24 24"><rect x="8" y="6" width="8" height="14" rx="4"/><path d="M3 12h5"/><path d="M16 12h5"/><path d="M5 18l3-2"/><path d="M19 18l-3-2"/><path d="M5 6l3 2"/><path d="M19 6l-3 2"/></svg>;
    case 'warn':        return <svg {...s} className={className} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>;
    case 'stethoscope': return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M11 2v2"/><path d="M5 2v2"/><path d="M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1"/><path d="M8 15a6 6 0 0 0 12 0v-3"/><circle cx="20" cy="10" r="2"/></svg>;
    case 'file':        return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8l6 6v12a2 2 0 0 1-2 2z"/><path d="M14 2v6h6"/></svg>;
    case 'shield':      return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></svg>;
    case 'check':       return <svg {...s} className={className} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>;
    case 'x':           return <svg {...s} className={className} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>;
    case 'spin':        return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-6.219-8.56" /></svg>;
    case 'arrow':       return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>;
    case 'chevdown':    return <svg {...s} className={className} viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>;
    case 'zap':         return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/></svg>;
    case 'doc':         return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>;
    case 'clock':       return <svg {...s} className={className} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>;
    case 'flow':        return <svg {...s} className={className} viewBox="0 0 24 24"><circle cx="6" cy="6" r="3"/><circle cx="18" cy="6" r="3"/><circle cx="12" cy="18" r="3"/><path d="M9 6h6"/><path d="M7.5 8.5l3 6.5"/><path d="M16.5 8.5l-3 6.5"/></svg>;
    case 'gantt':       return <svg {...s} className={className} viewBox="0 0 24 24"><path d="M3 6h7"/><path d="M7 12h11"/><path d="M11 18h7"/></svg>;
    case 'graph':       return <svg {...s} className={className} viewBox="0 0 24 24"><circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="m8 7 8 0"/><path d="m7 8 5 8"/><path d="m17 8-5 8"/></svg>;
    default:            return null;
  }
}

/* Stage status renderer — used inside both subway and compute nodes. */
function StatusBadge({ status, retry }) {
  const map = {
    done:    { label: 'Done',    cls: 'green' },
    running: { label: 'Running', cls: 'blue' },
    failed:  { label: retry ? 'Failed · retrying' : 'Failed', cls: 'red' },
    pending: { label: 'Queued',  cls: 'muted' },
    skipped: { label: 'Skipped', cls: 'muted' },
  };
  const m = map[status] || map.pending;
  return <span className={`pill ${m.cls}`}>
    {status === 'running' && <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'currentColor', display: 'inline-block' }} />}
    {m.label}
  </span>;
}

/* Right-rail detail body: shared between A and C. Renders selected stage + tabs. */
function RailDetail({ stage, decision, events }) {
  const [tab, setTab] = React.useState('overview');
  if (!stage && !decision) return <div style={{ padding: 30, textAlign: 'center', color: 'var(--fg-3)', fontSize: 12 }}>Select a stage in the flow to inspect it.</div>;

  if (decision) {
    return (
      <React.Fragment>
        <div className="rail-head">
          <div className="rail-eyebrow"><span className="pill purple">◇ Decision</span></div>
          <div className="rail-title">{decision.label}</div>
          <div className="rail-sub">A branch chosen by the orchestrator at runtime.</div>
        </div>
        <div className="rail-body">
          <div className="rail-section">
            <div className="rail-section-h">Outcome</div>
            <dl className="rail-kv">
              <dt>chosen</dt><dd className="ok">{decision.chosen}</dd>
              <dt>at</dt><dd>{decision.at}</dd>
            </dl>
          </div>
          <div className="rail-section">
            <div className="rail-section-h">Branches</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {decision.alternatives.map(a => (
                <div key={a} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px', borderRadius: 6, background: a === decision.chosen ? 'var(--accent-soft)' : 'var(--bg-2)', border: '1px solid', borderColor: a === decision.chosen ? 'rgba(68,147,248,.40)' : 'var(--border-1)' }}>
                  <span className="pill" style={{ background: a === decision.chosen ? 'var(--accent)' : 'var(--bg-3)', color: a === decision.chosen ? '#fff' : 'var(--fg-3)', borderColor: 'transparent' }}>{a === decision.chosen ? 'taken' : 'not taken'}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: a === decision.chosen ? 'var(--fg-1)' : 'var(--fg-3)' }}>{a}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rail-section">
            <div className="rail-section-h">Rationale</div>
            <div style={{ fontSize: 12, color: 'var(--fg-2)', lineHeight: 1.55 }}>{decision.rationale}</div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'output',   label: 'Output' },
    { id: 'events',   label: 'Activity', count: events.filter(e => e.stage === stage.id).length },
    { id: 'logs',     label: 'Logs' },
  ];

  return (
    <React.Fragment>
      <div className="rail-head">
        <div className="rail-eyebrow">
          <span className={`st-${stage.status}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <span className="st-dot" /> <span className="st-label">{stage.status}</span>
          </span>
          {stage.dur && stage.dur !== '—' && <span style={{ color: 'var(--fg-4)', fontFamily: 'var(--font-mono)', fontSize: 10.5 }}>{stage.dur}</span>}
        </div>
        <div className="rail-title">{stage.name}</div>
        <div className="rail-sub">{stage.desc}</div>
      </div>
      <div className="rail-tabs">
        {tabs.map(t => (
          <button key={t.id} className={`rail-tab ${tab === t.id ? 'active' : ''}`} onClick={() => setTab(t.id)}>
            {t.label}{t.count != null && <span className="count">{t.count}</span>}
          </button>
        ))}
      </div>
      <div className="rail-body">
        {tab === 'overview' && (
          <React.Fragment>
            {stage.status === 'failed' && stage.error && (
              <div className="rail-section">
                <div className="rail-section-h" style={{ color: 'var(--red)' }}>Error</div>
                <div className="blob" style={{ borderColor: 'rgba(248,81,73,.35)' }}>{stage.error}</div>
                <div style={{ marginTop: 8, display: 'flex', gap: 6 }}>
                  <span className="pill amber">Retry 1 of 3 queued</span>
                  <span className="pill muted">backoff 4s</span>
                </div>
              </div>
            )}
            {stage.status === 'skipped' && stage.skipReason && (
              <div className="rail-section">
                <div className="rail-section-h">Skip reason</div>
                <div style={{ fontSize: 12, color: 'var(--fg-2)', lineHeight: 1.55 }}>{stage.skipReason}</div>
              </div>
            )}
            <div className="rail-section">
              <div className="rail-section-h">Metrics</div>
              <dl className="rail-kv">
                <dt>status</dt><dd>{stage.status}</dd>
                {stage.metrics.confidence != null && <React.Fragment><dt>confidence</dt><dd>{stage.metrics.confidence}</dd></React.Fragment>}
                {stage.metrics.evidence != null && <React.Fragment><dt>evidence</dt><dd>{stage.metrics.evidence}</dd></React.Fragment>}
                {stage.metrics.tokens != null && <React.Fragment><dt>tokens</dt><dd>{stage.metrics.tokens}</dd></React.Fragment>}
                {stage.metrics.cost != null && <React.Fragment><dt>cost</dt><dd>{stage.metrics.cost}</dd></React.Fragment>}
                {stage.dur && <React.Fragment><dt>duration</dt><dd>{stage.dur}</dd></React.Fragment>}
              </dl>
            </div>
          </React.Fragment>
        )}
        {tab === 'output' && (
          <div className="rail-section">
            <div className="rail-section-h">Result data</div>
            <div className="blob">{stage.id === 'anomaly' ? `{
  "regressions": 17,
  "baseline_runs": 4,
  "drift_pct": 0.31,
  "top_signal": "perf_p99_query_search"
}` : stage.id === 'rca' ? `// streaming…
investigating: 17 failures
└─ cluster_1 (search_api)  ← in progress
   ├─ tool: read_logs
   └─ tool: search_traces` : stage.id === 'cluster' ? `{
  "clusters": 4,
  "cluster_sizes": [9, 4, 3, 1]
}` : '— no output yet —'}</div>
          </div>
        )}
        {tab === 'events' && (
          <div className="rail-section">
            {events.filter(e => e.stage === stage.id).map((e, i) => (
              <div key={i} className={`rail-evt ${e.kind === 'decision' ? 'decision' : ''}`}>
                <span className="when">{e.at}</span>
                <div className="body"><div className="what">{e.what}</div></div>
              </div>
            ))}
          </div>
        )}
        {tab === 'logs' && (
          <div className="rail-section">
            <div className="blob" style={{ minHeight: 200 }}>{`[${stage.id}] starting…
[${stage.id}] loaded config from /etc/testlookup/pipeline.yml
[${stage.id}] ${stage.status === 'running' ? 'streaming partial output…' : stage.status === 'failed' ? 'error: see Overview tab' : 'completed in ' + stage.dur}`}</div>
          </div>
        )}
      </div>
    </React.Fragment>
  );
}

/* Mode-tab strip: Live / Debug / Audit / Compare. */
function ModeTabs({ mode, setMode, isLive }) {
  const tabs = [
    { id: 'live',    label: 'Live',    icon: 'spin', live: true },
    { id: 'debug',   label: 'Debug',   icon: 'bug' },
    { id: 'audit',   label: 'Audit',   icon: 'doc' },
    { id: 'compare', label: 'Compare', icon: 'graph' },
  ];
  return (
    <div className="ab-tabs">
      {tabs.map(t => (
        <button key={t.id} className={`ab-tab ${mode === t.id ? 'active' : ''}`} onClick={() => setMode(t.id)}>
          {t.live && isLive && mode === t.id && <span className="live-dot" />}
          <Glyph name={t.icon} />
          {t.label}
          {t.id === 'live' && isLive && mode !== 'live' && <span className="ab-pill">Live</span>}
        </button>
      ))}
    </div>
  );
}

/* Top bar — page header + run picker + LLM mode chip. */
function TopBar({ flowIcon }) {
  return (
    <div className="ab-topbar">
      <div className="ab-title-block">
        <div className="ab-eyebrow">
          <span style={{ color: 'var(--fg-3)' }}>AI Reports</span>
          <Glyph name="chevdown" className="" />
          <span style={{ color: 'var(--fg-2)' }}>Agent Pipeline</span>
        </div>
        <div className="ab-title">Workflow · Run {RUN.shortId}</div>
      </div>
      <div className="ab-spacer" />
      <span className="ab-modechip"><Glyph name="bot" /> LLM Mode</span>
      <div className="ab-runpicker">
        <span className="pulse" />
        <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.25 }}>
          <span className="rid">{RUN.shortId} · {RUN.branch}</span>
          <span className="rmeta">Running · started {RUN.startedAtLabel} · {RUN.elapsed} elapsed</span>
        </div>
        <span className="rsep" />
        <span className="rchev"><Glyph name="chevdown" /></span>
      </div>
      <a href={`/agents/reports/${RUN.shortId}`}
         style={{ display: 'inline-flex', alignItems: 'center', gap: 6, height: 32, padding: '0 12px',
                  background: 'var(--accent-soft)', color: 'var(--accent-2)',
                  border: '1px solid rgba(68,147,248,.40)', borderRadius: 8,
                  fontSize: 12, fontWeight: 500, textDecoration: 'none', whiteSpace: 'nowrap' }}
         title="Open the executive summary report for this run">
        <Glyph name="doc" />
        Summary report
        <Glyph name="arrow" />
      </a>
      <div className="ab-trigger">
        <Glyph name="zap" />
        <input placeholder="Paste run UUID to trigger…" />
        <button title="Trigger pipeline"><Glyph name="arrow" /></button>
      </div>
    </div>
  );
}

/* Verdict card — shown when the run completes. Mirrors the real /agents page tail. */
const VERDICT = {
  buildId: 'ci-build-1',
  branch: 'release/v4.21',
  totalDuration: '10m 40s',
  finishedAt: '16:18:53',
  verdict: 'CONDITIONAL GO',
  verdictTone: 'amber',
  failuresHeadline: '1 failure detected',
  metrics: [
    { label: 'Pass Rate',      value: '88.9%', tone: 'amber' },
    { label: 'Total Tests',    value: '1,284', tone: 'fg' },
    { label: 'Failed',         value: '17',    tone: 'red' },
    { label: 'Skipped',        value: '0',     tone: 'fg' },
    { label: 'Failure Groups', value: '4',     tone: 'fg' },
    { label: 'Anomalies',      value: '6',     tone: 'fg' },
  ],
  blame: { label: 'Product Bug', count: 1, share: 100, tone: 'red' },
  takeaways: [
    'All 17 failures cluster into 4 defect-shaped groups; cluster_1 (search_api) accounts for 9.',
    'Routing chose LLM mode (17 > heuristic threshold of 5) — RCA evidence pack attached.',
    'Flaky Sentinel hit a transient ClickHouse timeout; retried and recovered cleanly.',
  ],
  nextActions: [
    'Review application logs for cluster_1 (search_api)',
    'Check recent commits to the affected service on release/v4.21',
    'Decide whether to file the 4 defect candidates as Jira tickets',
  ],
  evidence: { sources: 'logs, traces, run_history (4 baselines)', flaky: 'None confirmed' },
};

window.SHARED = { RUN, STAGES, DECISION, EVENTS, RECENT_RUNS, VERDICT, Glyph, StatusBadge, RailDetail, ModeTabs, TopBar };
