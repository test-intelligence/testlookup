// Direction B — Track + Gantt (full implementation).
// Layout: TopBar / ModeTabs / [ FlowStrip + Gantt + Activity ] | RightRail.

const { Glyph, RUN, STAGES, DECISION, EVENTS, VERDICT, RailDetail, ModeTabs, TopBar } = window.SHARED;

const T_MAX = 180;          // seconds shown on the axis
const NOW = 82;             // virtual "now" for this snapshot

function DirBGantt() {
  const [mode, setMode] = React.useState('live');
  const [selectedId, setSelectedId] = React.useState('rca');
  const [zoom, setZoom] = React.useState(1);
  const [showCompleted, setShowCompleted] = React.useState(false);

  const stage = STAGES.find(s => s.id === selectedId);
  const decision = selectedId === DECISION.id ? DECISION : null;

  return (
    <div className="ab-root">
      <TopBar />
      <ModeTabs mode={mode} setMode={setMode} isLive={!showCompleted} />
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto', minWidth: 0 }}>
          <RunHeader showCompleted={showCompleted} setShowCompleted={setShowCompleted} zoom={zoom} setZoom={setZoom} />
          <FlowStrip selectedId={selectedId} onSelect={setSelectedId} showCompleted={showCompleted} />
          <Gantt selectedId={selectedId} onSelect={setSelectedId} zoom={zoom} showCompleted={showCompleted} />
          {showCompleted && <VerdictPanel />}
          <ActivityFeed onSelectStage={setSelectedId} onSelectDecision={() => setSelectedId(DECISION.id)} />
        </div>
        <div className="rail">
          <RailDetail stage={decision ? null : stage} decision={decision} events={EVENTS} />
        </div>
      </div>
    </div>
  );
}

function RunHeader({ showCompleted, setShowCompleted, zoom, setZoom }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 24px', background: 'var(--bg-1)', borderBottom: '1px solid var(--border-1)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600 }}>Run</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5, color: 'var(--fg-2)' }}>{RUN.shortId}</span>
        <span style={{ color: 'var(--fg-faint)' }}>·</span>
        <span style={{ fontSize: 12, color: 'var(--fg-2)' }}>{RUN.branch}</span>
        <span style={{ color: 'var(--fg-faint)' }}>·</span>
        <span style={{ fontSize: 12, color: 'var(--fg-3)' }}>{RUN.elapsed} elapsed</span>
      </div>
      <span style={{ flex: 1 }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 11, color: 'var(--fg-3)' }}>Zoom</span>
        <div style={{ display: 'flex', gap: 2, padding: 2, background: 'var(--bg-2)', border: '1px solid var(--border-1)', borderRadius: 6 }}>
          {[0.75, 1, 1.5, 2].map(z => (
            <button key={z} onClick={() => setZoom(z)}
              style={{ padding: '3px 8px', fontSize: 11, fontFamily: 'var(--font-mono)', borderRadius: 4, border: 0, cursor: 'pointer',
                       background: zoom === z ? 'var(--bg-3)' : 'transparent',
                       color: zoom === z ? 'var(--fg-1)' : 'var(--fg-3)' }}>{z}×</button>
          ))}
        </div>
      </div>
      <button onClick={() => setShowCompleted(!showCompleted)}
        style={{ background: showCompleted ? 'var(--accent-soft)' : 'var(--bg-2)', color: showCompleted ? 'var(--accent-2)' : 'var(--fg-2)',
                 border: '1px solid', borderColor: showCompleted ? 'rgba(68,147,248,.40)' : 'var(--border-1)',
                 borderRadius: 6, padding: '5px 10px', fontSize: 11.5, cursor: 'pointer' }}>
        {showCompleted ? 'Showing completed-run snapshot' : 'Preview completed-run snapshot'}
      </button>
    </div>
  );
}

function FlowStrip({ selectedId, onSelect, showCompleted }) {
  const COL_W = 142, ROWS_H = 88, COLS = 8;
  const W = COLS * COL_W;
  const nodeXY = s => [s.col * COL_W + COL_W / 2, 22 + s.row * ROWS_H];
  const decXY = [DECISION.col * COL_W + COL_W / 2, 22 + DECISION.row * ROWS_H];
  const statusOverride = (s) => showCompleted && (s.status === 'running' || s.status === 'pending') ? 'done' : s.status;

  return (
    <div style={{ background: 'var(--bg-1)', borderBottom: '1px solid var(--border-1)', padding: '14px 24px 22px', overflowX: 'auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
        <Glyph name="flow" />
        <div style={{ fontSize: 12, color: 'var(--fg-2)', fontWeight: 600 }}>Stage flow</div>
        <span style={{ flex: 1 }} />
        <span style={{ fontSize: 11, color: 'var(--fg-3)', fontFamily: 'var(--font-mono)' }}>9 stages · 1 decision · 1 retry · 1 skipped</span>
      </div>
      <div style={{ position: 'relative', width: W, height: 22 + 2 * ROWS_H }}>
        <svg width={W} height={22 + 2 * ROWS_H} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
          <defs>
            <marker id="b-arrow-grey" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
              <path d="M0,0 L10,5 L0,10 z" fill="var(--border-strong)" />
            </marker>
            <marker id="b-arrow-blue" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
              <path d="M0,0 L10,5 L0,10 z" fill="var(--accent)" />
            </marker>
          </defs>
          <Line a={nodeXY(STAGES.find(s => s.id === 'ingestion'))} b={nodeXY(STAGES.find(s => s.id === 'anomaly'))} active />
          <Line a={nodeXY(STAGES.find(s => s.id === 'anomaly'))}   b={[decXY[0] - 16, decXY[1]]} active />
          <Line a={[decXY[0] + 16, decXY[1]]} b={nodeXY(STAGES.find(s => s.id === 'rca'))} active label="llm" tone="accent" />
          <Line a={nodeXY(STAGES.find(s => s.id === 'rca'))}     b={nodeXY(STAGES.find(s => s.id === 'summary'))} dashed />
          <Line a={nodeXY(STAGES.find(s => s.id === 'summary'))} b={nodeXY(STAGES.find(s => s.id === 'release'))} dashed />
          <Line a={[decXY[0], decXY[1] + 16]} b={nodeXY(STAGES.find(s => s.id === 'cluster'))} dashed muted curve label="parallel" />
          <Line a={nodeXY(STAGES.find(s => s.id === 'cluster'))} b={nodeXY(STAGES.find(s => s.id === 'flaky'))}   active />
          <Line a={nodeXY(STAGES.find(s => s.id === 'flaky'))}   b={nodeXY(STAGES.find(s => s.id === 'health'))}  dashed />
          <Line a={nodeXY(STAGES.find(s => s.id === 'health'))}  b={nodeXY(STAGES.find(s => s.id === 'summary'))} dashed curveUp />
          <Line a={nodeXY(STAGES.find(s => s.id === 'cluster'))} b={nodeXY(STAGES.find(s => s.id === 'triage'))} ghost />
        </svg>

        {STAGES.map(s => {
          const [x, y] = nodeXY(s);
          const status = statusOverride(s);
          return (
            <div key={s.id} className={`b-node ${selectedId === s.id ? 'selected' : ''}`}
                 onClick={() => onSelect(s.id)}
                 style={{ position: 'absolute', left: x - 38, top: y - 18, width: 76, cursor: 'pointer' }}>
              <div className="b-node-circle" style={{ margin: '0 auto', width: 34, height: 34,
                background: status === 'done' ? 'var(--green-soft)' : status === 'running' ? 'var(--accent-soft)'
                          : status === 'failed' ? 'var(--red-soft)' : status === 'skipped' ? 'transparent' : 'var(--bg-2)',
                borderColor: status === 'done' ? 'rgba(63,185,80,.45)' : status === 'running' ? 'rgba(68,147,248,.45)'
                          : status === 'failed' ? 'rgba(248,81,73,.45)' : status === 'skipped' ? 'var(--fg-faint)' : 'var(--border-2)',
                borderStyle: status === 'skipped' ? 'dashed' : 'solid',
                color: status === 'done' ? 'var(--green)' : status === 'running' ? 'var(--accent-2)'
                          : status === 'failed' ? 'var(--red)' : 'var(--fg-faint)',
                opacity: status === 'skipped' ? .55 : 1,
              }} title={s.skipReason || ''}>
                <Glyph name={s.glyph} />
              </div>
              <div className="b-node-name" style={{ marginTop: 6, textAlign: 'center', maxWidth: 110, color: selectedId === s.id ? 'var(--fg-1)' : 'var(--fg-2)', fontWeight: selectedId === s.id ? 600 : 500 }}>{s.name}</div>
              {status === 'running' && <div style={{ position: 'absolute', top: -3, left: '50%', transform: 'translateX(-50%)', width: 6, height: 6, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 0 3px var(--accent-soft)', animation: 'pulse 1.6s infinite' }} />}
              {status === 'failed' && <div style={{ position: 'absolute', top: -3, left: '50%', transform: 'translateX(-50%)', width: 6, height: 6, borderRadius: '50%', background: 'var(--red)' }} />}
            </div>
          );
        })}

        <div style={{ position: 'absolute', left: decXY[0] - 14, top: decXY[1] - 14, cursor: 'pointer' }} onClick={() => onSelect(DECISION.id)}>
          <div style={{ width: 28, height: 28, transform: 'rotate(45deg)', border: '1.5px solid var(--purple)',
                        background: selectedId === DECISION.id ? 'rgba(163,113,247,.22)' : 'rgba(163,113,247,.10)',
                        borderRadius: 4, boxShadow: selectedId === DECISION.id ? '0 0 0 3px var(--purple-soft)' : 'none' }} />
          <div style={{ position: 'absolute', left: '50%', top: 36, transform: 'translateX(-50%)', fontSize: 10, fontFamily: 'var(--font-mono)', color: 'var(--purple)', whiteSpace: 'nowrap' }}>
            ◇ {DECISION.label}
          </div>
        </div>
      </div>
    </div>
  );
}

function Line({ a, b, active, dashed, muted, ghost, curve, curveUp, label, tone }) {
  const stroke = active ? 'var(--accent)' : ghost ? 'var(--fg-faint)' : muted ? 'var(--fg-3)' : 'var(--border-strong)';
  const sw = active ? 2 : 1.6;
  const dashArr = dashed || ghost ? '4 4' : '0';
  let d;
  if (curve || curveUp) {
    const mx = (a[0] + b[0]) / 2;
    d = `M${a[0]},${a[1]} C ${mx},${a[1]} ${mx},${b[1]} ${b[0]},${b[1]}`;
  } else {
    d = `M${a[0]},${a[1]} L${b[0]},${b[1]}`;
  }
  return (
    <g opacity={ghost ? .35 : 1}>
      <path d={d} fill="none" stroke={stroke} strokeWidth={sw} strokeDasharray={dashArr} markerEnd={`url(#b-arrow-${active ? 'blue' : 'grey'})`} />
      {label && (
        <foreignObject x={(a[0] + b[0]) / 2 - 26} y={(a[1] + b[1]) / 2 - 9} width="52" height="18">
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, padding: '0 5px', borderRadius: 3, lineHeight: 1.7,
                            background: tone === 'accent' ? 'var(--accent-soft)' : 'var(--bg-2)',
                            color: tone === 'accent' ? 'var(--accent-2)' : 'var(--fg-3)',
                            border: '1px solid', borderColor: tone === 'accent' ? 'rgba(68,147,248,.40)' : 'var(--border-1)' }}>{label}</span>
          </div>
        </foreignObject>
      )}
    </g>
  );
}

function Gantt({ selectedId, onSelect, zoom, showCompleted }) {
  // Order stages by start time, with pending/skipped pinned to bottom of their lane
  const sorted = STAGES.slice().sort((a, b) => {
    const order = { ingestion: 0, anomaly: 1, cluster: 2, rca: 3, triage: 4, flaky: 5, health: 6, summary: 7, release: 8 };
    return (order[a.id] ?? 99) - (order[b.id] ?? 99);
  });

  const tMax = T_MAX;
  const widthFactor = `${zoom * 100}%`;
  const pct = ms => `${(ms / tMax) * 100}%`;
  const TICKS = [0, 15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165, 180];

  // For completed snapshot, show all bars finished within timeline
  const cstart = (s) => {
    if (s.startMs != null) return s.startMs;
    if (showCompleted) return ({ summary: 142, release: 165 })[s.id] ?? 60;
    return 175;
  };
  const cend = (s, now) => {
    if (s.endMs != null) {
      if (s.status === 'running' && !showCompleted) return now;
      return s.endMs;
    }
    if (showCompleted) return ({ summary: 165, release: 175 })[s.id] ?? 70;
    return 178;
  };
  const cstatus = (s) => showCompleted && (s.status === 'running' || s.status === 'pending') ? 'done' : s.status;

  const now = showCompleted ? tMax : NOW;

  return (
    <div className="b-gantt" style={{ background: 'var(--bg-page)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
        <Glyph name="gantt" />
        <div style={{ fontSize: 12, color: 'var(--fg-2)', fontWeight: 600 }}>Timeline</div>
        <span style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 14, fontSize: 10.5, color: 'var(--fg-3)' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 16, height: 6, background: 'var(--green)', borderRadius: 2 }} />done</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 16, height: 6, background: 'linear-gradient(90deg, var(--accent), rgba(68,147,248,.35))', borderRadius: 2 }} />running</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 16, height: 6, background: 'var(--red)', borderRadius: 2 }} />failed</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 16, height: 6, background: 'repeating-linear-gradient(45deg, var(--bg-3) 0 4px, transparent 4px 8px)', borderRadius: 2, border: '1px dashed var(--fg-faint)' }} />skipped</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 16, height: 6, background: 'var(--bg-3)', borderRadius: 2, border: '1px dashed var(--border-2)' }} />queued</span>
        </div>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <div style={{ minWidth: `calc(680px * ${zoom} + 336px)` }}>
          {/* axis row */}
          <div style={{ display: 'grid', gridTemplateColumns: `180px ${widthFactor} 92px 64px`, gap: 14, alignItems: 'center', paddingBottom: 30 }}>
            <div />
            <div className="b-gantt-axis" style={{ position: 'relative', height: 28 }}>
              {TICKS.map(t => (
                <div key={t} className="b-tick" style={{ left: pct(t) }}>{t}s</div>
              ))}
              <div className="b-now-line" style={{ left: pct(now) }} />
              <div className="b-now-flag" style={{ left: pct(now), transform: 'translateX(-50%)' }}>{showCompleted ? 'DONE' : `NOW · ${now}s`}</div>
              <div className="b-decision-line" style={{ left: pct(57) }} />
              <div className="b-decision-flag" style={{ left: pct(57), transform: 'translateX(-50%)', top: -36 }}>◇ {DECISION.label} → {DECISION.chosen}</div>
            </div>
            <div />
            <div />
          </div>

          {sorted.map(s => {
            const status = cstatus(s);
            const isSkipped = status === 'skipped';
            const isPending = status === 'pending';
            const start = cstart(s);
            const end = cend(s, now);
            return (
              <div key={s.id}
                   className={`b-row ${selectedId === s.id ? 'selected' : ''} ${status}`}
                   style={{ gridTemplateColumns: `180px ${widthFactor} 92px 64px`, cursor: 'pointer' }}
                   onClick={() => onSelect(s.id)}>
                <div className="b-cell-name">
                  <span className="stage-glyph" style={{
                    color: status === 'done' ? 'var(--green)' : status === 'running' ? 'var(--accent-2)'
                        : status === 'failed' ? 'var(--red)' : 'var(--fg-faint)'
                  }}><Glyph name={s.glyph} /></span>
                  <span style={{ fontSize: 12.5 }}>{s.name}</span>
                  {status === 'failed' && <span className="pill amber" style={{ marginLeft: 4, fontSize: 9.5 }}>retry</span>}
                </div>
                <div className="b-cell-track">
                  {!isPending && !isSkipped && (
                    <div className={`b-bar ${status}`} style={{ left: pct(start), width: pct(Math.max(end - start, 1.5)) }} title={`${s.name} · ${s.dur}`} />
                  )}
                  {isSkipped && (
                    <div className="b-bar skipped" style={{ left: pct(start), width: pct(8) }} title={s.skipReason} />
                  )}
                  {isPending && (
                    <div className="b-bar pending" style={{ left: pct(start), width: pct(15) }} title="Queued" />
                  )}
                  {status === 'running' && s.etaMs && (
                    <div style={{ position: 'absolute', left: pct(now), top: 4, bottom: 4,
                                  width: pct(Math.max(s.etaMs - now, 1)),
                                  background: 'repeating-linear-gradient(45deg, transparent 0 4px, var(--accent-soft) 4px 8px)',
                                  borderRadius: 4, opacity: .7 }} title={`ETA ${s.etaMs}s`} />
                  )}
                  {/* Stage label inside the bar when wide enough */}
                  {!isPending && !isSkipped && (end - start) > 20 && (
                    <div style={{ position: 'absolute', left: `calc(${pct(start)} + 8px)`, top: 4, height: 14,
                                  fontFamily: 'var(--font-mono)', fontSize: 10, color: '#fff', mixBlendMode: 'screen',
                                  pointerEvents: 'none', textShadow: '0 1px 2px rgba(0,0,0,.4)' }}>{s.dur}</div>
                  )}
                </div>
                <div className="b-cell-dur">{s.dur || '—'}</div>
                <div className="b-cell-status" style={{
                  color: status === 'done' ? 'var(--green)' : status === 'running' ? 'var(--accent-2)'
                      : status === 'failed' ? 'var(--red)' : 'var(--fg-faint)'
                }}>{status}</div>
              </div>
            );
          })}
        </div>
      </div>

      <Summary />
    </div>
  );
}

function Summary() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginTop: 20, padding: 12, background: 'var(--bg-1)', border: '1px solid var(--border-1)', borderRadius: 10 }}>
      <Stat k="Wall clock"      v={RUN.elapsed} />
      <Stat k="Critical path"   v="rca · 1m 22s" tone="accent" />
      <Stat k="Parallel saving" v="≈ 17s" tone="green" />
      <Stat k="LLM cost so far" v="$0.62" />
    </div>
  );
}

function Stat({ k, v, tone }) {
  return (
    <div>
      <div style={{ fontSize: 9.5, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase' }}>{k}</div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, marginTop: 3,
                    color: tone === 'accent' ? 'var(--accent-2)' : tone === 'green' ? 'var(--green)' : 'var(--fg-1)' }}>{v}</div>
    </div>
  );
}

function VerdictPanel() {
  return (
    <div style={{ padding: '18px 24px', background: 'var(--bg-page)' }}>
      <div style={{ background: 'var(--bg-1)', border: '1px solid var(--border-1)', borderRadius: 14, padding: 18 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600 }}>Build {VERDICT.buildId} · finished {VERDICT.finishedAt} · {VERDICT.totalDuration}</div>
            <div style={{ fontSize: 17, color: 'var(--fg-1)', fontWeight: 600, marginTop: 4 }}>{VERDICT.failuresHeadline}</div>
          </div>
          <span className="pill amber" style={{ fontSize: 11, fontWeight: 700, padding: '4px 10px' }}>{VERDICT.verdict}</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8, marginTop: 16 }}>
          {VERDICT.metrics.map(m => (
            <div key={m.label} style={{ background: 'var(--bg-2)', borderRadius: 8, padding: '10px 8px', textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 18, fontWeight: 700,
                            color: m.tone === 'red' ? 'var(--red)' : m.tone === 'amber' ? 'var(--amber)' : 'var(--fg-1)' }}>{m.value}</div>
              <div style={{ fontSize: 9.5, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', marginTop: 2 }}>{m.label}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginTop: 16 }}>
          <div>
            <div style={{ fontSize: 10.5, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600, marginBottom: 8 }}>Key takeaways</div>
            <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
              {VERDICT.takeaways.map((t, i) => (
                <li key={i} style={{ display: 'flex', gap: 8, fontSize: 12, color: 'var(--fg-2)' }}>
                  <span style={{ color: 'var(--green)', flex: '0 0 auto', marginTop: 2 }}><Glyph name="check" /></span>{t}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div style={{ fontSize: 10.5, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600, marginBottom: 8 }}>Next actions</div>
            <ol style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
              {VERDICT.nextActions.map((t, i) => (
                <li key={i} style={{ display: 'flex', gap: 8, fontSize: 12, color: 'var(--fg-2)' }}>
                  <span style={{ flex: '0 0 auto', width: 18, height: 18, borderRadius: '50%', background: 'var(--bg-2)', border: '1px solid var(--border-1)', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--fg-3)' }}>{i + 1}</span>{t}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}

function ActivityFeed({ onSelectStage, onSelectDecision }) {
  return (
    <div style={{ padding: '14px 24px 24px', background: 'var(--bg-page)', borderTop: '1px solid var(--border-1)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
        <Glyph name="clock" />
        <div style={{ fontSize: 12, color: 'var(--fg-2)', fontWeight: 600 }}>Activity feed</div>
        <span style={{ fontSize: 10.5, color: 'var(--fg-3)', fontFamily: 'var(--font-mono)' }}>· tail of pipeline.log</span>
        <span style={{ flex: 1 }} />
        <span style={{ fontSize: 10.5, color: 'var(--fg-3)' }}>{EVENTS.length} events</span>
      </div>
      <div>
        {EVENTS.slice().reverse().map((e, i) => {
          const tone = e.kind === 'failed' ? 'red' : e.kind === 'completed' ? 'green' : e.kind === 'decision' ? 'purple' : e.kind === 'retry' ? 'amber' : 'muted';
          return (
            <div key={i} className={`rail-evt ${e.kind === 'decision' ? 'decision' : ''}`}
                 style={{ cursor: 'pointer', padding: '7px 0' }}
                 onClick={() => e.kind === 'decision' ? onSelectDecision() : onSelectStage(e.stage)}>
              <span className="when">{e.at}</span>
              <div className="body">
                <span className={`pill ${tone}`} style={{ marginRight: 8, fontSize: 9.5 }}>{e.kind}</span>
                <span style={{ fontSize: 12, color: 'var(--fg-1)' }}>{e.what}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.DirBGantt = DirBGantt;
