// Direction C — Compute graph. Dense metric-rich nodes laid out on a dotted
// canvas with explicit branch labels on edges. Power-user / debugger view.

const { Glyph, RUN, STAGES, DECISION, EVENTS, RailDetail, ModeTabs, TopBar, VERDICT } = window.SHARED;

function DirCCompute() {
  const [mode, setMode] = React.useState('debug');
  const [selectedId, setSelectedId] = React.useState('rca');
  const stage = STAGES.find(s => s.id === selectedId);
  const decision = selectedId === DECISION.id ? DECISION : null;

  return (
    <div className="ab-root">
      <TopBar />
      <ModeTabs mode={mode} setMode={setMode} isLive />
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <ComputeCanvas selectedId={selectedId} onSelect={setSelectedId} />
        <div className="rail">
          <RailDetail stage={decision ? null : stage} decision={decision} events={EVENTS} />
        </div>
      </div>
    </div>
  );
}

function ComputeCanvas({ selectedId, onSelect }) {
  // Hand-tuned positions — tighter than columns to fit metric-dense nodes.
  const POS = {
    ingestion: { x: 32,    y: 80 },
    anomaly:   { x: 290,   y: 80 },
    decision:  { x: 564,   y: 110 },
    rca:       { x: 700,   y: 30 },
    cluster:   { x: 700,   y: 250 },
    triage:    { x: 970,   y: 250 },   // skipped, dimmed
    flaky:     { x: 970,   y: 380 },
    health:    { x: 1240,  y: 380 },
    summary:   { x: 1240,  y: 80 },
    release:   { x: 1500,  y: 80 },
  };
  const NODE_W = 226, NODE_H = 132;

  const ctr = id => {
    if (id === 'decision') return { x: POS.decision.x + 44, y: POS.decision.y + 44 };
    return { x: POS[id].x + NODE_W / 2, y: POS[id].y + NODE_H / 2 };
  };

  // Edges: from → to, optional label and chosen flag
  const EDGES = [
    { from: 'ingestion', to: 'anomaly' },
    { from: 'anomaly',   to: 'decision' },
    { from: 'decision',  to: 'rca',     label: 'llm', chosen: true },
    { from: 'decision',  to: 'cluster', label: 'parallel', chosen: true },
    { from: 'decision',  to: 'triage',  label: 'heuristic', notchosen: true },
    { from: 'rca',       to: 'summary', dashed: true },
    { from: 'cluster',   to: 'flaky' },
    { from: 'flaky',     to: 'health',  dashed: true },
    { from: 'health',    to: 'summary', dashed: true },
    { from: 'summary',   to: 'release', dashed: true },
  ];

  const W = 1750, H = 560;

  return (
    <div className="c-canvas" style={{ overflow: 'auto' }}>
      <div style={{ position: 'relative', width: W, height: H, padding: 24 }}>
        <svg width={W} height={H} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
          <defs>
            <marker id="c-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">
              <path d="M0,0 L10,5 L0,10 z" fill="var(--border-strong)" />
            </marker>
            <marker id="c-arrow-blue" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">
              <path d="M0,0 L10,5 L0,10 z" fill="var(--accent)" />
            </marker>
            <marker id="c-arrow-faint" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">
              <path d="M0,0 L10,5 L0,10 z" fill="var(--fg-faint)" />
            </marker>
          </defs>
          {EDGES.map((e, i) => {
            const a = ctr(e.from), b = ctr(e.to);
            const stroke = e.chosen ? 'var(--accent)' : e.notchosen ? 'var(--fg-faint)' : 'var(--border-strong)';
            const marker = e.chosen ? 'c-arrow-blue' : e.notchosen ? 'c-arrow-faint' : 'c-arrow';
            const dash = e.dashed || e.notchosen ? '5 5' : '0';
            const opacity = e.notchosen ? .55 : 1;
            // bezier path: out from right side of `from`, in from left side of `to`
            const fromRight = e.from === 'decision' ? a.x + 30 : a.x + NODE_W / 2;
            const toLeft = e.to === 'decision' ? b.x - 30 : b.x - NODE_W / 2;
            const ay = a.y, by = b.y;
            const cx = (fromRight + toLeft) / 2;
            const d = `M${fromRight},${ay} C ${cx},${ay} ${cx},${by} ${toLeft},${by}`;
            return <path key={i} d={d} fill="none" stroke={stroke} strokeWidth={2} strokeDasharray={dash} opacity={opacity} markerEnd={`url(#${marker})`} />;
          })}
        </svg>
        {EDGES.filter(e => e.label).map((e, i) => {
          const a = ctr(e.from), b = ctr(e.to);
          const x = (a.x + b.x) / 2 + 24;
          const y = (a.y + b.y) / 2;
          return <div key={i} className={`c-edge-label ${e.chosen ? 'chosen' : 'notchosen'}`} style={{ left: x, top: y }}>{e.label}</div>;
        })}

        {STAGES.map(s => (
          <ComputeNode key={s.id} s={s} pos={POS[s.id]} selected={selectedId === s.id} onClick={() => onSelect(s.id)} />
        ))}

        {/* Decision diamond */}
        <div className="c-decision" onClick={() => onSelect(DECISION.id)}
             style={{
               left: POS.decision.x, top: POS.decision.y,
               borderColor: selectedId === DECISION.id ? 'var(--purple)' : 'var(--purple)',
               background: selectedId === DECISION.id ? 'rgba(163,113,247,.18)' : 'rgba(163,113,247,.08)',
               boxShadow: selectedId === DECISION.id ? '0 0 0 3px var(--purple-soft)' : 'none',
             }}>
          <div className="c-decision-inner">
            <div className="dec-eyebrow">decide</div>
            <div className="dec-key">{DECISION.label.replace('route_', '')}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ComputeNode({ s, pos, selected, onClick }) {
  const cls = `c-node st-${s.status} ${s.status === 'failed' ? 'failed' : ''} ${s.status === 'running' ? 'running' : ''} ${s.status === 'skipped' ? 'skipped' : ''} ${selected ? 'selected' : ''}`;
  const tone = s.status === 'done' ? 'green' : s.status === 'running' ? 'blue'
            : s.status === 'failed' ? 'red' : 'muted';
  return (
    <div className={cls} onClick={onClick} style={{ left: pos.x, top: pos.y }} title={s.skipReason || ''}>
      <div className="c-node-head">
        <div className="st-icon" style={{ width: 22, height: 22 }}><Glyph name={s.glyph} /></div>
        <div className="c-node-name">{s.name}</div>
        <span className={`pill ${tone}`} style={{ fontSize: 9.5 }}>
          {s.status === 'running' && <span style={{ width: 4, height: 4, borderRadius: '50%', background: 'currentColor', display: 'inline-block' }} />}
          {s.status}
        </span>
      </div>
      <div className="c-node-desc">{s.desc}</div>
      <div className="c-node-metrics">
        <div className="c-metric"><div className="k">duration</div><div className="v">{s.dur || '—'}</div></div>
        {s.metrics.confidence != null
          ? <div className={`c-metric ${parseInt(s.metrics.confidence) > 80 ? 'ok' : ''}`}><div className="k">conf</div><div className="v">{s.metrics.confidence}</div></div>
          : <div className="c-metric"><div className="k">evidence</div><div className="v">{s.metrics.evidence ?? '—'}</div></div>}
        {s.metrics.tokens != null
          ? <div className="c-metric"><div className="k">tokens</div><div className="v">{s.metrics.tokens}</div></div>
          : <div className="c-metric"><div className="k">tokens</div><div className="v">—</div></div>}
        {s.metrics.cost != null
          ? <div className={`c-metric ${parseFloat(s.metrics.cost?.replace('$','')) > 0.5 ? 'warn' : ''}`}><div className="k">cost</div><div className="v">{s.metrics.cost}</div></div>
          : <div className="c-metric"><div className="k">cost</div><div className="v">—</div></div>}
      </div>
      {s.status === 'failed' && (
        <div style={{ marginTop: 8, fontSize: 10.5, color: 'var(--red)', display: 'flex', alignItems: 'center', gap: 6 }}>
          <Glyph name="warn" /> retry 1/3 queued
        </div>
      )}
      {s.status === 'running' && (
        <div className="c-node-spark">
          <div style={{ height: 4, borderRadius: 2, background: 'var(--accent-soft)', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: '47%', background: 'var(--accent)', borderRadius: 2 }} />
          </div>
          <div style={{ marginTop: 4, display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--fg-3)', fontFamily: 'var(--font-mono)' }}>
            <span>{s.dur}</span><span>ETA {(s.etaMs - s.startMs) || '—'}s total</span>
          </div>
        </div>
      )}
    </div>
  );
}

window.DirCCompute = DirCCompute;
