// Direction A — Subway Map. Clean horizontal DAG with a decision diamond,
// stage cards on a track, and a right-rail inspector. Designed to be the
// "most legible at a glance" option.

const { Glyph, StatusBadge, RailDetail, ModeTabs, TopBar, RUN, STAGES, DECISION, EVENTS, VERDICT } = window.SHARED;

function DirASubway() {
  const [mode, setMode] = React.useState('live');
  const [selectedId, setSelectedId] = React.useState('rca');
  const [showVerdict, setShowVerdict] = React.useState(false);
  const stage = STAGES.find(s => s.id === selectedId);
  const decision = selectedId === DECISION.id ? DECISION : null;

  return (
    <div className="ab-root">
      <TopBar />
      <ModeTabs mode={mode} setMode={setMode} isLive={!showVerdict} />

      {/* track section */}
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
          <SubwayTrack selectedId={selectedId} onSelect={setSelectedId} showVerdict={showVerdict} />
          <RunMeta showVerdict={showVerdict} setShowVerdict={setShowVerdict} />
          {showVerdict && <VerdictPanel />}
          <EventStrip onSelectStage={setSelectedId} onSelectDecision={() => setSelectedId(DECISION.id)} />
        </div>
        <div className="rail">
          <RailDetail stage={decision ? null : stage} decision={decision} events={EVENTS} />
        </div>
      </div>
    </div>
  );
}

function SubwayTrack({ selectedId, onSelect, showVerdict }) {
  // Two-row subway: row 0 is the main spine (Ingestion → Anomaly → ◇ → RCA → Summary → Release Risk),
  // row 1 is the parallel quality lane (Cluster, Triage*, Flaky, Health) that branches off after the decision.
  // Card widths are uniform; the SVG tracks below align to card centers via CSS grid columns.

  const COLS = 8;            // 0..7
  const COL_W = 188;
  const CARD_W = 172;
  const ROW_H = 132;
  const TOP_PAD = 28;

  const cardX = col => col * COL_W + (COL_W - CARD_W) / 2;
  const cardCenterX = col => col * COL_W + COL_W / 2;
  const rowCenterY = row => TOP_PAD + row * ROW_H + 56;          // rough vertical center of card
  const trackW = COLS * COL_W;

  // Compute status to drive the bg color of cards
  const stagesByCol = {};
  STAGES.forEach(s => { stagesByCol[`${s.col}-${s.row}`] = s; });

  const decisionCenter = { x: cardCenterX(DECISION.col), y: rowCenterY(DECISION.row) };

  return (
    <div style={{ position: 'relative', minWidth: trackW + 48, padding: '24px 24px 48px', background: 'var(--bg-page)', overflow: 'hidden' }}>
      {/* Title strip */}
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 18 }}>
        <div>
          <div style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600 }}>Pipeline · deep</div>
          <div style={{ fontSize: 17, color: 'var(--fg-1)', fontWeight: 600, marginTop: 3 }}>Stage flow</div>
        </div>
        <div style={{ display: 'flex', gap: 14, alignItems: 'center', fontSize: 11.5, color: 'var(--fg-3)' }}>
          <Legend dot="green" label="Done" />
          <Legend dot="blue"  label="Running" />
          <Legend dot="red"   label="Failed" />
          <Legend dot="muted" label="Queued" />
          <Legend dot="dash"  label="Skipped" />
        </div>
      </div>

      {/* SVG track lines under cards */}
      <svg width={trackW} height={TOP_PAD + 2 * ROW_H + 8} style={{ position: 'absolute', left: 24, top: 70, pointerEvents: 'none' }}>
        <defs>
          <marker id="a-arrow-grey" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0,0 L10,5 L0,10 z" fill="var(--border-strong)" />
          </marker>
          <marker id="a-arrow-blue" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0,0 L10,5 L0,10 z" fill="var(--accent)" />
          </marker>
        </defs>
        {/* Spine: Ingestion(0,0) → Anomaly(1,0) → ◇(2,0) → RCA(3,0) → Summary(6,0) → Release(7,0) */}
        <Edge from={[cardCenterX(0), rowCenterY(0)]} to={[cardCenterX(1), rowCenterY(0)]} active />
        <Edge from={[cardCenterX(1), rowCenterY(0)]} to={[decisionCenter.x - 30, decisionCenter.y]} active />
        <Edge from={[decisionCenter.x + 30, decisionCenter.y]} to={[cardCenterX(3), rowCenterY(0)]} active label="llm" labelTone="accent" />
        <Edge from={[cardCenterX(3), rowCenterY(0)]} to={[cardCenterX(6), rowCenterY(0)]} dashed dashedReason />
        <Edge from={[cardCenterX(6), rowCenterY(0)]} to={[cardCenterX(7), rowCenterY(0)]} dashed />

        {/* Branch from decision down to row1 (heuristic path, not taken) */}
        <Edge from={[decisionCenter.x, decisionCenter.y + 30]} to={[cardCenterX(3), rowCenterY(1)]} curve dashed muted label="heuristic" labelTone="muted" />

        {/* Parallel lane row1: cluster(3,1) ─ triage(4,1, skipped) and flaky(4,1)  */}
        {/* Cluster done → Flaky failed; Flaky → Health pending; Health → Summary join */}
        <Edge from={[cardCenterX(3), rowCenterY(1)]} to={[cardCenterX(4), rowCenterY(1)]} active />
        <Edge from={[cardCenterX(4), rowCenterY(1)]} to={[cardCenterX(5), rowCenterY(1)]} dashed />
        <Edge from={[cardCenterX(5), rowCenterY(1)]} to={[cardCenterX(6), rowCenterY(0)]} dashed curveUp />

        {/* Triage skipped — show as ghost branch off cluster */}
        <Edge from={[cardCenterX(3), rowCenterY(1) + 24]} to={[cardCenterX(4), rowCenterY(1) + 36]} ghost />
      </svg>

      {/* Cards: row 0 spine */}
      {[
        STAGES.find(s => s.id === 'ingestion'),
        STAGES.find(s => s.id === 'anomaly'),
        STAGES.find(s => s.id === 'rca'),
        STAGES.find(s => s.id === 'summary'),
        STAGES.find(s => s.id === 'release'),
      ].map(s => (
        <SubwayCard key={s.id} s={s} x={cardX(s.col) + 24} y={TOP_PAD + s.row * ROW_H + 70} w={CARD_W}
                    selected={selectedId === s.id} onClick={() => onSelect(s.id)} showVerdict={showVerdict} />
      ))}

      {/* Cards: row 1 parallel lane */}
      {[
        STAGES.find(s => s.id === 'cluster'),
        STAGES.find(s => s.id === 'triage'),
        STAGES.find(s => s.id === 'flaky'),
        STAGES.find(s => s.id === 'health'),
      ].map((s, i) => {
        // Triage and Flaky overlap visually — push triage left a hair, flaky right a hair
        const xShift = s.id === 'triage' ? -24 : s.id === 'flaky' ? 18 : 0;
        return (
          <SubwayCard key={s.id} s={s} x={cardX(s.col) + 24 + xShift} y={TOP_PAD + s.row * ROW_H + 70} w={CARD_W}
                      selected={selectedId === s.id} onClick={() => onSelect(s.id)} small showVerdict={showVerdict} />
        );
      })}

      {/* Decision diamond */}
      <div
        onClick={() => onSelect(DECISION.id)}
        style={{
          position: 'absolute',
          left: decisionCenter.x + 24 - 32,
          top: 70 + decisionCenter.y - 32,
          cursor: 'pointer',
        }}
        title={DECISION.rationale}
      >
        <div className="a-decision" style={{
          borderColor: selectedId === DECISION.id ? 'var(--purple)' : 'var(--border-2)',
          background: selectedId === DECISION.id ? 'rgba(163,113,247,.10)' : 'var(--bg-1)',
          boxShadow: selectedId === DECISION.id ? '0 0 0 3px var(--purple-soft)' : 'none',
        }}>
          <div style={{ transform: 'rotate(-45deg)', textAlign: 'center', lineHeight: 1 }}>
            <div style={{ fontSize: 11, color: 'var(--purple)' }}>◇</div>
          </div>
        </div>
        <div className="a-decision-label">{DECISION.label}</div>
        <div className="a-decision-chosen">→ {DECISION.chosen}</div>
      </div>
    </div>
  );
}

function Edge({ from, to, active, dashed, ghost, curve, curveUp, muted, label, labelTone }) {
  const stroke = active ? 'var(--accent)' : muted ? 'var(--fg-faint)' : ghost ? 'var(--fg-faint)' : 'var(--border-strong)';
  const sw = active ? 2.5 : 1.75;
  const dashArr = dashed || ghost ? '5 5' : '0';
  const opacity = ghost ? .35 : 1;
  let d;
  if (curve) {
    const mx = (from[0] + to[0]) / 2;
    d = `M${from[0]},${from[1]} C ${mx},${from[1]} ${mx},${to[1]} ${to[0]},${to[1]}`;
  } else if (curveUp) {
    const mx = (from[0] + to[0]) / 2;
    d = `M${from[0]},${from[1]} C ${mx},${from[1]} ${mx},${to[1]} ${to[0]},${to[1]}`;
  } else {
    d = `M${from[0]},${from[1]} L${to[0]},${to[1]}`;
  }
  return (
    <g>
      <path d={d} fill="none" stroke={stroke} strokeWidth={sw} strokeDasharray={dashArr} opacity={opacity}
            markerEnd={`url(#a-arrow-${active ? 'blue' : 'grey'})`} />
      {label && (
        <foreignObject x={(from[0] + to[0]) / 2 - 28} y={(from[1] + to[1]) / 2 - 11} width="56" height="22">
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <span style={{
              fontFamily: 'var(--font-mono)', fontSize: 9.5, padding: '1px 6px', borderRadius: 4, lineHeight: 1.6,
              background: labelTone === 'accent' ? 'var(--accent-soft)' : 'var(--bg-1)',
              color: labelTone === 'accent' ? 'var(--accent-2)' : 'var(--fg-faint)',
              border: '1px solid', borderColor: labelTone === 'accent' ? 'rgba(68,147,248,.40)' : 'var(--border-1)',
            }}>{label}</span>
          </div>
        </foreignObject>
      )}
    </g>
  );
}

function SubwayCard({ s, x, y, w, selected, onClick, small, showVerdict }) {
  // When the run is "completed" mode, override running → done so the snapshot reads as a finished run.
  const status = showVerdict && s.status === 'running' ? 'done'
                : showVerdict && s.status === 'pending' ? 'done'
                : s.status;
  const cls = `a-stage st-${status} ${status === 'failed' ? 'failed' : ''} ${status === 'running' ? 'running' : ''} ${status === 'skipped' ? 'skipped' : ''} ${selected ? 'selected' : ''}`;
  return (
    <div className={cls} onClick={onClick}
         style={{ position: 'absolute', left: x, top: y, width: w, paddingTop: small ? 10 : 12, paddingBottom: small ? 10 : 12 }}
         title={s.skipReason || ''}>
      <div className="a-row1">
        <div className="st-icon"><Glyph name={s.glyph} /></div>
        <div className="a-name" style={{ fontSize: small ? 12.5 : 13.5 }}>{s.name}</div>
        <span className="st-dot" />
      </div>
      {!small && <div className="a-desc">{s.desc}</div>}
      <div className="a-foot">
        <span className="st-label">{status}</span>
        {s.dur && s.dur !== '—' && <span style={{ color: 'var(--fg-faint)' }}>·</span>}
        {s.dur && s.dur !== '—' && <span>{s.dur}</span>}
        {status === 'failed' && <span style={{ color: 'var(--amber)' }}>· retry queued</span>}
      </div>
      {status === 'running' && <div className="progress-bar" />}
    </div>
  );
}

function Legend({ dot, label }) {
  const styles = {
    green: { background: 'var(--green)' },
    blue:  { background: 'var(--accent)', boxShadow: '0 0 0 3px var(--accent-soft)' },
    red:   { background: 'var(--red)' },
    muted: { background: 'var(--fg-faint)' },
    dash:  { background: 'transparent', border: '1px dashed var(--fg-3)' },
  };
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span style={{ width: 9, height: 9, borderRadius: '50%', flex: '0 0 auto', ...styles[dot] }} />
      {label}
    </span>
  );
}

function RunMeta({ showVerdict, setShowVerdict }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '10px 24px', background: 'var(--bg-1)', borderTop: '1px solid var(--border-1)', borderBottom: '1px solid var(--border-1)' }}>
      <span style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600 }}>Run</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--fg-2)' }}>{RUN.shortId}</span>
      <span style={{ color: 'var(--fg-faint)' }}>·</span>
      <span style={{ fontSize: 12, color: 'var(--fg-2)' }}>{RUN.branch}</span>
      <span style={{ color: 'var(--fg-faint)' }}>·</span>
      <span style={{ fontSize: 12, color: 'var(--fg-3)' }}>{RUN.triggeredBy}</span>
      <span style={{ color: 'var(--fg-faint)' }}>·</span>
      <span className="pill muted" style={{ textTransform: 'uppercase', fontSize: 9.5, letterSpacing: '.08em' }}>{RUN.pipeline}</span>
      <span style={{ color: 'var(--fg-faint)' }}>·</span>
      <span style={{ fontSize: 12, color: 'var(--fg-2)', fontFamily: 'var(--font-mono)' }}>{RUN.totalTests.toLocaleString()} tests</span>
      <span style={{ color: 'var(--fg-faint)' }}>·</span>
      <span style={{ fontSize: 12, color: 'var(--red)', fontFamily: 'var(--font-mono)' }}>{RUN.failedCount} failed</span>
      <span style={{ flex: 1 }} />
      <a href={`/agents/reports/${RUN.shortId}/summary`}
         style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: 'var(--accent-2)', textDecoration: 'none' }}>
        <Glyph name="doc" /> Open full summary report <Glyph name="arrow" />
      </a>
      <span style={{ width: 1, height: 18, background: 'var(--border-1)' }} />
      <button onClick={() => setShowVerdict(!showVerdict)}
        style={{ background: showVerdict ? 'var(--accent-soft)' : 'var(--bg-2)', color: showVerdict ? 'var(--accent-2)' : 'var(--fg-2)',
                 border: '1px solid', borderColor: showVerdict ? 'rgba(68,147,248,.40)' : 'var(--border-1)',
                 borderRadius: 6, padding: '5px 10px', fontSize: 11.5, cursor: 'pointer' }}>
        {showVerdict ? 'Showing completed-run snapshot' : 'Preview completed-run snapshot'}
      </button>
    </div>
  );
}

function VerdictPanel() {
  return (
    <div style={{ padding: '18px 24px', background: 'var(--bg-page)' }}>
      <div style={{ background: 'var(--bg-1)', border: '1px solid var(--border-1)', borderRadius: 14, padding: 18 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600 }}>Build {VERDICT.buildId} · finished {VERDICT.finishedAt} · {VERDICT.totalDuration}</div>
            <div style={{ fontSize: 17, color: 'var(--fg-1)', fontWeight: 600, marginTop: 4 }}>{VERDICT.failuresHeadline}</div>
          </div>
          <span className="pill amber" style={{ fontSize: 11, fontWeight: 700, padding: '4px 10px' }}>{VERDICT.verdict}</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8, marginTop: 16 }}>
          {VERDICT.metrics.map(m => (
            <div key={m.label} style={{ background: 'var(--bg-2)', borderRadius: 8, padding: '10px 8px', textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 18, fontWeight: 700,
                            color: m.tone === 'red' ? 'var(--red)' : m.tone === 'amber' ? 'var(--amber)' : 'var(--fg-1)' }}>{m.value}</div>
              <div style={{ fontSize: 9.5, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', marginTop: 2 }}>{m.label}</div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 14, padding: '8px 12px', background: 'var(--bg-2)', borderRadius: 8, border: '1px solid var(--border-1)' }}>
          <Glyph name="alert" />
          <span style={{ fontSize: 12 }}><span style={{ color: 'var(--red)', fontWeight: 600 }}>{VERDICT.blame.label}</span> — {VERDICT.blame.count} failure ({VERDICT.blame.share}%)</span>
          <span style={{ flex: 1 }} />
          <span style={{ width: 80, height: 6, background: 'var(--bg-3)', borderRadius: 999, overflow: 'hidden' }}>
            <span style={{ display: 'block', width: `${VERDICT.blame.share}%`, height: '100%', background: 'var(--red)' }} />
          </span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginTop: 16 }}>
          <div>
            <div style={{ fontSize: 10.5, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600, marginBottom: 8 }}>Key takeaways</div>
            <ul style={{ margin: 0, paddingLeft: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
              {VERDICT.takeaways.map((t, i) => (
                <li key={i} style={{ display: 'flex', gap: 8, fontSize: 12, color: 'var(--fg-2)' }}>
                  <span style={{ color: 'var(--green)', flex: '0 0 auto', marginTop: 2 }}><Glyph name="check" /></span>{t}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div style={{ fontSize: 10.5, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600, marginBottom: 8 }}>Next actions</div>
            <ol style={{ margin: 0, paddingLeft: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
              {VERDICT.nextActions.map((t, i) => (
                <li key={i} style={{ display: 'flex', gap: 8, fontSize: 12, color: 'var(--fg-2)' }}>
                  <span style={{ flex: '0 0 auto', width: 18, height: 18, borderRadius: '50%', background: 'var(--bg-2)', border: '1px solid var(--border-1)', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--fg-3)' }}>{i + 1}</span>{t}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}

function EventStrip({ onSelectStage, onSelectDecision }) {
  return (
    <div style={{ padding: '14px 24px 24px', background: 'var(--bg-page)', borderTop: '1px solid var(--border-1)' }}>
      <div style={{ fontSize: 11, color: 'var(--fg-3)', letterSpacing: '.10em', textTransform: 'uppercase', fontWeight: 600, marginBottom: 10 }}>Event feed · live</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        {EVENTS.slice().reverse().map((e, i) => {
          const tone = e.kind === 'failed' ? 'red' : e.kind === 'completed' ? 'green' : e.kind === 'decision' ? 'purple' : e.kind === 'retry' ? 'amber' : 'muted';
          return (
            <div key={i} className={`rail-evt ${e.kind === 'decision' ? 'decision' : ''}`}
                 style={{ cursor: 'pointer', padding: '7px 0' }}
                 onClick={() => e.kind === 'decision' ? onSelectDecision() : onSelectStage(e.stage)}>
              <span className="when">{e.at}</span>
              <div className="body">
                <span className={`pill ${tone}`} style={{ marginRight: 8 }}>{e.kind}</span>
                <span style={{ fontSize: 12, color: 'var(--fg-1)' }}>{e.what}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.DirASubway = DirASubway;
