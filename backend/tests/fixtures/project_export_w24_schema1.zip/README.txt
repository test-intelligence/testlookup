TestLookup project export: settings and test catalog

This ZIP holds ONE project's settings and test catalog (suites, test cases and their versions,
plans, strategies, releases, gates, policies, ownership rules, workflow definitions, cadences),
one JSONL file per part under entities/<table>/, in dependency order.

It does NOT hold: run history, logs, attachments or other stored files, members, roles, API keys,
or any secret. Secrets kept in the deployment's secret store never travel; a secret typed into a
free-text or JSON field is replaced by [REDACTED]. Pattern fields (ownership, attribution and
classification patterns, test fingerprints) travel byte-exact.

Import it as a NEW project (Settings > Project data > Import as a new project, or
`testlookup projects import <zip>`). Nothing is merged into an existing project; webhooks, team
channels, Git integrations and notification rules arrive switched off, run cadences paused.

Verification (tamper-evident checksum chain + Ed25519 signature):
1. For each file listed in manifest.json `files`, compute its SHA-256 and compare it with the
   manifest. No other file may be in the ZIP except signature.json.
2. signature.json: its `manifest_sha256` must equal the SHA-256 of manifest.json. Verify
   `signature` (base64 Ed25519) over the UTF-8 statement
   `testlookup-compliance-pack-v1\n<pack_id>\n<manifest_sha256>\n<key_id>\n` with the exporting
   deployment's public key for `key_id` (GET /api/v1/compliance-packs/signing-keys).
3. `testlookup compliance-pack verify <zip> --public-key <pem>` does all of it offline.
An archive without signature.json is tamper-evident only.
